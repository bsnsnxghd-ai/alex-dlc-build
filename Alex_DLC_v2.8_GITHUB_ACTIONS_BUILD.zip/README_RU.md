# Alex DLC v2.8 — сборка DLL для RimWorld 1.5.4297

Это небольшой пакет для сборки `AlexDLC.Logistics.dll`. Устанавливать игру, Visual Studio, Python или .NET на свой компьютер не нужно: сборка выполняется на GitHub.

## Как получить DLL

1. Распакуй этот ZIP на компьютере.
2. На GitHub создай новый пустой репозиторий, например `alex-dlc-build`. Не добавляй README, .gitignore или лицензию при создании.
3. В пустом репозитории нажми **uploading an existing file**. Перетащи **всё содержимое распакованной папки**, включая `.github`, `Source`, `NuGet.Config`, `.gitignore` и оба файла инструкции/проверки. Сам ZIP и внешнюю папку загружать не надо. Нажми **Commit changes**.
4. Открой вкладку **Code** и проверь: прямо в корне видны `.github`, `Source` и `NuGet.Config`. В `.github/workflows` должен быть `build.yml`. Если `.github` не загрузилась, нажми **Add file → Upload files** и перетащи эту папку отдельно. В Проводнике при необходимости включи **Вид → Показать → Скрытые элементы**.
5. Открой **Actions → Build Alex DLC v2.8 DLL → Run workflow → Run workflow**. Выбери основную ветку (обычно `main`). Если GitHub предлагает включить Actions, включи их.
6. Дождись зелёной отметки. Открой этот запуск и внизу, в разделе **Artifacts**, нажми **AlexDLC.Logistics-RimWorld-1.5.4297**.
7. Распакуй скачанный artifact ZIP: внутри будет **AlexDLC.Logistics.dll**. Сохрани его для следующего этапа сборки мода.

Если кнопки **Run workflow** нет, проверь наличие `.github/workflows/build.yml` в основной ветке репозитория и обнови страницу Actions. Если сборка красная, открой упавший шаг и передай его журнал ошибок; готовая DLL в таком случае не подтверждена. Artifact хранится 30 дней.

## Что находится внутри

```text
.github/workflows/build.yml
Source/AlexDLC.Logistics/AlexDLC.Logistics.csproj
Source/AlexDLC.Logistics/LogisticsBuildings.cs
NuGet.Config
.gitignore
README_RU.md
STATIC_CHECK_RU.txt
```

Проект использует .NET Framework 4.7.2 и строго заданный пакет `Krafs.Rimworld.Ref` версии 1.5.4297. Зависимости автоматически скачиваются с NuGet. Workflow запускается только вручную и публикует только DLL; отдельные токены и secrets не нужны.

Это **не полный мод для установки в RimWorld**. Текстуры, игровые Defs и скрипт активации XML не нужны для компиляции и в этот компактный пакет не включены. Сохрани исходный архив мода: он потребуется для интеграции DLL и соответствующих XML на следующем этапе. Сам C#-исходник сохранён без изменений.

Проведена статическая проверка, описанная в `STATIC_CHECK_RU.txt`. GitHub Actions ещё не запускался, DLL не собрана и её работоспособность не подтверждена. Даже успешная компиляция требует последующей проверки полного мода в игре.

Справка: [ручной запуск Actions](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow), [пакет RimWorld 1.5.4297](https://www.nuget.org/packages/Krafs.Rimworld.Ref/1.5.4297).
