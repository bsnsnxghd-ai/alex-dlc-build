using System;
using System.Collections.Generic;
using RimWorld;
using Verse;

namespace AlexDLC.Logistics
{
    public static class AlexLogisticsUtility
    {
        public const int PacketSize = 10;

        public static bool PowerAllows(Building building)
        {
            CompPowerTrader power = building.TryGetComp<CompPowerTrader>();
            return power == null || power.PowerOn;
        }

        public static IntVec3 Forward(Building building)
        {
            return building.Position + building.Rotation.FacingCell;
        }

        public static IntVec3 Backward(Building building)
        {
            IntVec3 f = building.Rotation.FacingCell;
            return new IntVec3(building.Position.x - f.x, building.Position.y, building.Position.z - f.z);
        }

        public static IntVec3 RightOf(Building building)
        {
            IntVec3 f = building.Rotation.FacingCell;
            return building.Position + new IntVec3(f.z, 0, -f.x);
        }

        public static IntVec3 LeftOf(Building building)
        {
            IntVec3 f = building.Rotation.FacingCell;
            return building.Position + new IntVec3(-f.z, 0, f.x);
        }

        public static Thing FirstMovableItemAt(IntVec3 cell, Map map)
        {
            if (map == null || !cell.InBounds(map))
                return null;

            List<Thing> things = cell.GetThingList(map);
            for (int i = 0; i < things.Count; i++)
            {
                Thing thing = things[i];
                if (thing != null && !thing.Destroyed && thing.Spawned &&
                    thing.def != null && thing.def.category == ThingCategory.Item)
                    return thing;
            }

            return null;
        }

        public static Building_Storage StorageAt(IntVec3 cell, Map map)
        {
            if (map == null || !cell.InBounds(map))
                return null;

            List<Thing> things = cell.GetThingList(map);
            for (int i = 0; i < things.Count; i++)
            {
                Building_Storage storage = things[i] as Building_Storage;
                if (storage != null)
                    return storage;
            }

            return null;
        }

        public static bool IsLogisticsNodeAt(IntVec3 cell, Map map)
        {
            if (map == null || !cell.InBounds(map))
                return false;

            List<Thing> things = cell.GetThingList(map);
            for (int i = 0; i < things.Count; i++)
            {
                Thing thing = things[i];
                if (thing == null || thing.def == null)
                    continue;

                string name = thing.def.defName;
                if (name == "AlexDLC_ConveyorSegment" ||
                    name == "AlexDLC_ConveyorJunction" ||
                    name == "AlexDLC_LoaderArm" ||
                    name == "AlexDLC_UnloaderDock" ||
                    name == "AlexDLC_SmartSorter")
                    return true;
            }

            return false;
        }

        public static bool CanReceive(Thing item, IntVec3 destination, Map map, bool requireStorage)
        {
            if (item == null || map == null || !destination.InBounds(map))
                return false;

            Building_Storage storage = StorageAt(destination, map);
            if (storage != null)
                return storage.GetStoreSettings().AllowedToAccept(item);

            if (requireStorage)
                return false;

            if (!IsLogisticsNodeAt(destination, map))
                return false;

            // One visible packet per conveyor cell. If the next cell is occupied, the line jams naturally.
            return FirstMovableItemAt(destination, map) == null;
        }

        public static bool TryMovePacket(Thing source, IntVec3 destination, Map map, bool requireStorage)
        {
            if (source == null || !source.Spawned || map == null)
                return false;

            if (!CanReceive(source, destination, map, requireStorage))
                return false;

            IntVec3 origin = source.Position;
            Thing packet;
            bool wholeStack = source.stackCount <= PacketSize;

            if (wholeStack)
            {
                packet = source;
                packet.DeSpawn();
            }
            else
            {
                packet = source.SplitOff(PacketSize);
                if (packet.Spawned)
                    packet.DeSpawn();
            }

            if (GenPlace.TryPlaceThing(packet, destination, map, ThingPlaceMode.Direct))
                return true;

            // Safety fallback: never silently delete cargo if placement fails.
            if (!packet.Spawned)
                GenPlace.TryPlaceThing(packet, origin, map, ThingPlaceMode.Direct);

            return false;
        }

        public static string DirectionText(Rot4 rotation)
        {
            if (rotation == Rot4.North) return "север";
            if (rotation == Rot4.East) return "восток";
            if (rotation == Rot4.South) return "юг";
            return "запад";
        }
    }

    public abstract class Building_AlexLogisticsMover : Building
    {
        private int ticksUntilMove = 1;

        protected abstract int MoveInterval { get; }
        protected abstract bool TryMoveItem();

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            if (!respawningAfterLoad || ticksUntilMove <= 0)
            {
                int seed = Math.Abs(Position.x * 31 + Position.z * 17);
                ticksUntilMove = 1 + (seed % Math.Max(2, MoveInterval));
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref ticksUntilMove, "alexTicksUntilMove", 1);
        }

        public override void Tick()
        {
            base.Tick();

            if (!AlexLogisticsUtility.PowerAllows(this))
                return;

            ticksUntilMove--;
            if (ticksUntilMove > 0)
                return;

            ticksUntilMove = MoveInterval;
            TryMoveItem();
        }

        public override string GetInspectString()
        {
            string baseText = base.GetInspectString();
            string line = "Направление: " + AlexLogisticsUtility.DirectionText(Rotation);
            if (string.IsNullOrEmpty(baseText))
                return line;
            return baseText + "\n" + line;
        }
    }

    // Standard T2 belt. There are intentionally no fantasy speed tiers.
    public class Building_AlexConveyor : Building_AlexLogisticsMover
    {
        protected override int MoveInterval { get { return 18; } }

        protected override bool TryMoveItem()
        {
            Thing item = AlexLogisticsUtility.FirstMovableItemAt(Position, Map);
            if (item == null)
                return false;

            return AlexLogisticsUtility.TryMovePacket(
                item,
                AlexLogisticsUtility.Forward(this),
                Map,
                false);
        }
    }

    public class Building_AlexConveyorJunction : Building_AlexLogisticsMover
    {
        private int branchIndex;
        protected override int MoveInterval { get { return 18; } }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref branchIndex, "alexBranchIndex", 0);
        }

        protected override bool TryMoveItem()
        {
            Thing item = AlexLogisticsUtility.FirstMovableItemAt(Position, Map);
            if (item == null)
                return false;

            IntVec3[] targets =
            {
                AlexLogisticsUtility.Forward(this),
                AlexLogisticsUtility.RightOf(this),
                AlexLogisticsUtility.LeftOf(this)
            };

            for (int offset = 0; offset < targets.Length; offset++)
            {
                int idx = (branchIndex + offset) % targets.Length;
                IntVec3 target = targets[idx];
                if (!AlexLogisticsUtility.IsLogisticsNodeAt(target, Map) &&
                    AlexLogisticsUtility.StorageAt(target, Map) == null)
                    continue;

                if (AlexLogisticsUtility.TryMovePacket(item, target, Map, false))
                {
                    branchIndex = (idx + 1) % targets.Length;
                    return true;
                }
            }

            return false;
        }
    }

    // Loader dock: storage behind, conveyor in front.
    public class Building_AlexLoaderArm : Building_AlexLogisticsMover
    {
        protected override int MoveInterval { get { return 30; } }

        protected override bool TryMoveItem()
        {
            IntVec3 input = AlexLogisticsUtility.Backward(this);
            IntVec3 output = AlexLogisticsUtility.Forward(this);

            Building_Storage sourceStorage = AlexLogisticsUtility.StorageAt(input, Map);
            if (sourceStorage == null)
                return false;

            Thing item = AlexLogisticsUtility.FirstMovableItemAt(input, Map);
            if (item == null)
                return false;

            if (!AlexLogisticsUtility.IsLogisticsNodeAt(output, Map))
                return false;

            return AlexLogisticsUtility.TryMovePacket(item, output, Map, false);
        }
    }

    // Unloader dock: cargo enters its own cell from the rear belt and exits into storage in front.
    public class Building_AlexUnloaderDock : Building_AlexLogisticsMover
    {
        protected override int MoveInterval { get { return 18; } }

        protected override bool TryMoveItem()
        {
            Thing item = AlexLogisticsUtility.FirstMovableItemAt(Position, Map);
            if (item == null)
                return false;

            IntVec3 output = AlexLogisticsUtility.Forward(this);
            return AlexLogisticsUtility.TryMovePacket(item, output, Map, true);
        }
    }

    public class Building_AlexSmartSorter : Building_AlexLogisticsMover
    {
        protected override int MoveInterval { get { return 18; } }

        protected override bool TryMoveItem()
        {
            Thing item = AlexLogisticsUtility.FirstMovableItemAt(Position, Map);
            if (item == null)
                return false;

            IntVec3 right = AlexLogisticsUtility.RightOf(this);
            IntVec3 left = AlexLogisticsUtility.LeftOf(this);
            IntVec3 forward = AlexLogisticsUtility.Forward(this);

            // A filtered storage directly on a side acts as a simple Factorio-like filter output.
            Building_Storage rightStorage = AlexLogisticsUtility.StorageAt(right, Map);
            if (rightStorage != null && rightStorage.GetStoreSettings().AllowedToAccept(item))
                if (AlexLogisticsUtility.TryMovePacket(item, right, Map, true)) return true;

            Building_Storage leftStorage = AlexLogisticsUtility.StorageAt(left, Map);
            if (leftStorage != null && leftStorage.GetStoreSettings().AllowedToAccept(item))
                if (AlexLogisticsUtility.TryMovePacket(item, left, Map, true)) return true;

            return AlexLogisticsUtility.TryMovePacket(item, forward, Map, false);
        }
    }

    public class Building_AlexLogisticsController : Building
    {
        public override string GetInspectString()
        {
            string baseText = base.GetInspectString();
            string line = "Управление сетью: активно. Скорость T2 лент не изменяется.";
            if (string.IsNullOrEmpty(baseText))
                return line;
            return baseText + "\n" + line;
        }
    }

    // Prepared for the next stage. It is not activated by the v2.8 build script yet.
    public class Building_AlexOreDrillStation : Building
    {
        public override string GetInspectString()
        {
            string baseText = base.GetInspectString();
            string line = "T2 буровая: прототип выхода ресурса спереди";
            if (string.IsNullOrEmpty(baseText))
                return line;
            return baseText + "\n" + line;
        }
    }
}
